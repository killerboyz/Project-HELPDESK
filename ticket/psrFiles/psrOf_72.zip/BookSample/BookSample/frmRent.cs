﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BookSample
{
    public partial class frmRent : Form
    {
        public frmRent()
        {
            InitializeComponent();
        }

        DataSet DS = new DataSet();
        SqlDataAdapter DARent, DARentDetail, DAMem, DABook;
        SqlConnection CN;
        private void frmRent_Load(object sender, EventArgs e)
        {
            txtRentDate.Text = DateTime.Today.ToString("dd/MM/yyyy");

            CN = new SqlConnection();
            CN.ConnectionString = "Data Source=.; Initial Catalog=BookSample; User ID=sa; Password=123";

            string SQL = "Select * from tblRent";
            DARent = new SqlDataAdapter(SQL, CN);
            SqlCommandBuilder CBRent = new SqlCommandBuilder(DARent);
            DARent.Fill(DS, "Rent");

            SQL = "Select * from tblRentDetail";
            DARentDetail = new SqlDataAdapter(SQL, CN);
            SqlCommandBuilder CBRentDetail = new SqlCommandBuilder(DARentDetail);
            DARentDetail.Fill(DS, "RentDetail");

            SQL = "Select * from tblMember";
            DAMem = new SqlDataAdapter(SQL, CN);
            SqlCommandBuilder CBMem = new SqlCommandBuilder(DAMem);
            DAMem.Fill(DS, "Member");

            SQL = "Select * from tblBook";
            DABook = new SqlDataAdapter(SQL, CN);
            SqlCommandBuilder CBBook = new SqlCommandBuilder(DABook);
            DABook.Fill(DS, "Book");

            dgvRentDetail.AutoGenerateColumns = false;
            dgvRentDetail.DataSource = DSTemp.Tables["Detail"];

            btnNew.Enabled = true;
            btnSearchMember.Enabled = false;
            btnSearchBook.Enabled = false;
            btnRent.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            ClearData();
            DataRow[] DR = DS.Tables["Rent"].Select("", "RentID DESC");
            if (DR.Length == 0)
                txtRentID.Text = "1";
            else
            {
                int id = Convert.ToInt32(DR[0]["RentID"]) + 1;
                txtRentID.Text = id.ToString();
            }

            btnNew.Enabled = false;
            btnSearchMember.Enabled = true;
            btnSearchBook.Enabled = false;
            btnRent.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = true;
        }

        private void ClearData()
        {
            txtRentID.Clear();
            txtMemberID.Clear();
            txtMemberName.Clear();
            txtTel.Clear();
            txtMaxRent.Clear();
            txtTotalRent.Clear();
            txtBookID.Clear();
            txtBookName.Clear();
            txtRentPrice.Clear();
            txtFinePrice.Clear();
            txtReturnDay.Clear();
            DSTemp.Tables["Detail"].Clear();
        }

        public static string MemberID = "";
        private void btnSearchMember_Click(object sender, EventArgs e)
        {
            frmSearchMember F = new frmSearchMember();
            F.ShowDialog();
            if (MemberID == "") return;
            DataRow[] DR = DS.Tables["Member"].Select("MemberID='" + MemberID +"'");
            txtMemberID.Text = MemberID;
            txtMemberName.Text = DR[0]["MemberName"].ToString();
            txtTel.Text = DR[0]["Tel"].ToString();
            txtMaxRent.Text = DR[0]["MaxRent"].ToString();
            txtTotalRent.Text = DR[0]["TotalRent"].ToString();

            btnNew.Enabled = false;
            btnSearchMember.Enabled = false;
            btnSearchBook.Enabled = true;
            btnRent.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = true;
        }

        public static string BookID = "";
        private void btnSearchBook_Click(object sender, EventArgs e)
        {
            frmSearchBook F = new frmSearchBook();
            F.ShowDialog();
            if (BookID == "") return;
            DataRow[] DR = DS.Tables["Book"].Select("BookID='" + BookID + "'");
            txtBookID.Text = BookID;
            txtBookName.Text = DR[0]["BookName"].ToString();
            txtRentPrice.Text = Convert.ToDouble(DR[0]["RentPrice"]).ToString("n2");
            txtFinePrice.Text = Convert.ToDouble(DR[0]["FinePrice"]).ToString("n2");
            txtReturnDay.Text = DR[0]["ReturnDay"].ToString();

            btnNew.Enabled = false;
            btnSearchMember.Enabled = false;
            btnSearchBook.Enabled = true;
            btnRent.Enabled = true;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
        }

        private void btnRent_Click(object sender, EventArgs e)
        {
            DataRow[] DRCheck = DSTemp.Tables["Detail"].Select("BookID='" + txtBookID.Text + "'");
            if (DRCheck.Length == 0)
            {
                int MaxRent = Convert.ToInt32(txtMaxRent.Text);
                int TotalRent = Convert.ToInt32(txtTotalRent.Text);
                TotalRent++;
                if (TotalRent <= MaxRent)
                {
                    txtTotalRent.Text = TotalRent.ToString();

                    DataRow DR = DSTemp.Tables["Detail"].NewRow();
                    DR["BookID"] = txtBookID.Text;
                    DR["BookName"] = txtBookName.Text;
                    int ReturnDay = Convert.ToInt32(txtReturnDay.Text);
                    DateTime FixReturnDate = DateTime.Today.AddDays(ReturnDay);
                    DR["FixReturnDate"] = FixReturnDate;
                    DR["Price"] = txtRentPrice.Text;
                    DSTemp.Tables["Detail"].Rows.Add(DR);
                    CalculateTotalPrice();
                }
                else
                    MessageBox.Show("สมาชิกเช่าครบตามจำนวนที่เช่าได้แล้ว", "คำเตือน");
            }
            else
                MessageBox.Show("หนังสือเล่มนี้เลือกไปแล้ว","คำเตือน");

            btnNew.Enabled = false;
            btnSearchMember.Enabled = false;
            btnSearchBook.Enabled = true;
            btnRent.Enabled = true;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
        }

        private void CalculateTotalPrice()
        {
            double TotalPrice = 0;
            for (int i = 0; i < DSTemp.Tables["Detail"].Rows.Count; i++)
            {
                TotalPrice += Convert.ToDouble(DSTemp.Tables["Detail"].Rows[i]["Price"]);
            }
            txtTotalPrice.Text = TotalPrice.ToString("n2");
        }

        private void dgvRentDetail_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int i = e.RowIndex;
            if (e.ColumnIndex == 0)
            {
                int TotalRent = Convert.ToInt32(txtTotalRent.Text);
                TotalRent--;
                txtTotalRent.Text = TotalRent.ToString();

                DSTemp.Tables["Detail"].Rows[i].Delete();
                CalculateTotalPrice();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (DSTemp.Tables["Detail"].Rows.Count == 0)
                MessageBox.Show("ยังไม่ได้เลือกหนังสือที่จะเช่า", "คำเตือน");
            else
            {
                DataRow DRRent = DS.Tables["Rent"].NewRow();
                DRRent["RentID"] = txtRentID.Text;
                DRRent["RentDate"] = txtRentDate.Text;
                DRRent["MemberID"] = txtMemberID.Text;
                DRRent["TotalPrice"] = txtTotalPrice.Text;
                DS.Tables["Rent"].Rows.Add(DRRent);

                for (int i = 0; i < DSTemp.Tables["Detail"].Rows.Count; i++)
                {
                    DataRow DRRentDetail = DS.Tables["RentDetail"].NewRow();
                    DRRentDetail["RentID"] = txtRentID.Text;
                    DRRentDetail["BookID"] = DSTemp.Tables["Detail"].Rows[i]["BookID"];
                    DRRentDetail["FixReturnDate"] = DSTemp.Tables["Detail"].Rows[i]["FixReturnDate"];
                    DRRentDetail["Price"] = DSTemp.Tables["Detail"].Rows[i]["Price"];
                    DS.Tables["RentDetail"].Rows.Add(DRRentDetail);

                    DataRow[] DRBook = DS.Tables["Book"].Select("BookID='" + DSTemp.Tables["Detail"].Rows[i]["BookID"] + "'");
                    DRBook[0]["Status"] = "เช่า";

                    DataRow[] DRMember = DS.Tables["Member"].Select("MemberID='" + txtMemberID.Text + "'");
                    DRMember[0]["TotalRent"] = txtTotalRent.Text;
                }

                DARent.Update(DS, "Rent");
                DARentDetail.Update(DS, "RentDetail");
                DABook.Update(DS, "Book");
                DAMem.Update(DS, "Member");

                btnNew.Enabled = true;
                btnSearchMember.Enabled = false;
                btnSearchBook.Enabled = false;
                btnRent.Enabled = false;
                btnSave.Enabled = false;
                btnCancel.Enabled = false;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearData();
            btnNew.Enabled = true;
            btnSearchMember.Enabled = false;
            btnSearchBook.Enabled = false;
            btnRent.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
