﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BookSample
{
    public partial class frmSearchMember : Form
    {
        public frmSearchMember()
        {
            InitializeComponent();
        }

        DataSet DS = new DataSet();
        SqlDataAdapter DAMem;
        SqlConnection CN;
        DataView DV;
        private void frmSearchMember_Load(object sender, EventArgs e)
        {
            CN = new SqlConnection();
            CN.ConnectionString = "Data Source=.; Initial Catalog=BookSample; User ID=sa; Password=123";

            string SQL = "Select * from tblMember";
            DAMem = new SqlDataAdapter(SQL, CN);
            DAMem.Fill(DS, "Member");
            DV = new DataView(DS.Tables["Member"]);
            dgvMember.AutoGenerateColumns = false;
            dgvMember.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMember.DataSource = DV;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (rdbMemberID.Checked)
                DV.RowFilter = "MemberID like '%" + txtSearch.Text + "%'";
            else
                DV.RowFilter = "MemberName like '%" + txtSearch.Text + "%'";
        }

        private void dgvMember_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int i = e.RowIndex;
            if (Convert.ToInt32(DV[i]["TotalRent"]) == Convert.ToInt32(DV[i]["MaxRent"]))
            {
                MessageBox.Show("สมาชิกเช่าครบตามจำนวนที่เช่าได้แล้ว","คำเตือน");
                return;
            }
            if (i >= 0 && i < DV.Count)
            {
                frmRent.MemberID = DV[i]["MemberID"].ToString();
                this.Close();
            }
        }
    }
}
