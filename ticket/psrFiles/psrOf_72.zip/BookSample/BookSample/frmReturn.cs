﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BookSample
{
    public partial class frmReturn : Form
    {
        public frmReturn()
        {
            InitializeComponent();
        }
        
        DataSet DS = new DataSet();
        SqlDataAdapter DARentDetail, DAMem, DABook, DAJoinRent;
        SqlConnection CN;
        private void frmReturn_Load(object sender, EventArgs e)
        {
            txtReturnDate.Text = DateTime.Today.ToString("dd/MM/yyyy");

            CN = new SqlConnection();
            CN.ConnectionString = "Data Source=.; Initial Catalog=BookSample; User ID=sa; Password=123";

            string SQL = "Select * from tblRentDetail";
            DARentDetail = new SqlDataAdapter(SQL, CN);
            SqlCommandBuilder CBRentDetail = new SqlCommandBuilder(DARentDetail);
            DARentDetail.Fill(DS, "RentDetail");

            SQL = "Select * from tblMember";
            DAMem = new SqlDataAdapter(SQL, CN);
            SqlCommandBuilder CBMem = new SqlCommandBuilder(DAMem);
            DAMem.Fill(DS, "Member");

            SQL = "Select * from tblBook";
            DABook = new SqlDataAdapter(SQL, CN);
            SqlCommandBuilder CBBook = new SqlCommandBuilder(DABook);
            DABook.Fill(DS, "Book");

            SQL = "Select * from tblRent inner join tblMember on tblRent.MemberID = tblMember.MemberID";
            DAJoinRent = new SqlDataAdapter(SQL, CN);
            DAJoinRent.Fill(DS, "JoinRent");
        }

        public static string RentID = "";
        private void btnSearchRent_Click(object sender, EventArgs e)
        {
            frmSearchRent F = new frmSearchRent();
            F.ShowDialog();
            if (RentID == "") return;
            DataRow[] DR = DS.Tables["JoinRent"].Select("RentID=" + RentID);
            txtRentID.Text = RentID;
            txtRentDate.Text = Convert.ToDateTime(DR[0]["RentDate"]).ToString("dd/MM/yyyy");
            txtMemberID.Text = DR[0]["MemberID"].ToString();
            txtMemberName.Text = DR[0]["MemberName"].ToString();
            txtMaxRent.Text = DR[0]["MaxRent"].ToString();
            txtTotalRent.Text = DR[0]["TotalRent"].ToString();

            ShowBookDetail();
        }

        private void ShowBookDetail()
        {
            if (DS.Tables.Contains("BookDetail"))
                DS.Tables.Remove("BookDetail");

            string SQL = "Select * from tblRentDetail inner join tblBook on tblRentDetail.BookID = tblBook.BookID Where RentID =" + txtRentID.Text;
            SqlDataAdapter DA = new SqlDataAdapter(SQL, CN);
            DA.Fill(DS, "BookDetail");
            dgvRentDetail.AutoGenerateColumns = false;
            dgvRentDetail.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRentDetail.DataSource = DS.Tables["BookDetail"];
        }

        int i = 0;
        private void dgvRentDetail_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            i = e.RowIndex;
            if (DS.Tables["BookDetail"].Rows[i]["ReturnDate"] is DBNull)
                btnReturn.Enabled = true;
            else
                btnReturn.Enabled = false;
        }

        double TotalFine = 0;
        private void btnReturn_Click(object sender, EventArgs e)
        {
            //ปรับปรุงจำนวนที่เช่าไปแล้วในตาราง Member
            DataRow[] DRMember = DS.Tables["Member"].Select("MemberID='" + txtMemberID.Text + "'");
            DRMember[0]["TotalRent"] = Convert.ToInt32(DRMember[0]["TotalRent"]) - 1;
            txtTotalRent.Text = DRMember[0]["TotalRent"].ToString();

            //ปรับปรุงสถานะหนังสือในตาราง Book
            DataRow[] DRBook = DS.Tables["Book"].Select("BookID='" + DS.Tables["BookDetail"].Rows[i]["BookID"] + "'");
            DRBook[0]["Status"] = "ว่าง";

            //ปรับปรุงวันที่คืนในตาราง RentDetail
            DataRow[] DRRentDetail = DS.Tables["RentDetail"].Select("BookID='" + DS.Tables["BookDetail"].Rows[i]["BookID"] + "' and RentID =" + txtRentID.Text);
            DRRentDetail[0]["ReturnDate"] = txtReturnDate.Text;

            //ปรับปรุงค่าปรับในตาราง RentDetail
            DateTime FixReturnDate = Convert.ToDateTime(DRRentDetail[0]["FixReturnDate"]);
            DateTime ReturnDate = Convert.ToDateTime(txtReturnDate.Text);

            TimeSpan diff = ReturnDate.Subtract(FixReturnDate);
            if (diff.Days > 0)
                DRRentDetail[0]["Fine"] = Convert.ToDouble(DRBook[0]["FinePrice"]) * diff.Days;
            else
                DRRentDetail[0]["Fine"] = 0;
            TotalFine += Convert.ToDouble(DRRentDetail[0]["Fine"]);
            txtTotalFine.Text = TotalFine.ToString("n2");

            //ปรับปรุงลงฐานข้อมูล
            DARentDetail.Update(DS, "RentDetail");
            DABook.Update(DS, "Book");
            DAMem.Update(DS, "Member");
            ShowBookDetail();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }



    }
}
