﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BookSample
{
    public partial class frmSearchBook : Form
    {
        public frmSearchBook()
        {
            InitializeComponent();
        }

        DataSet DS = new DataSet();
        SqlDataAdapter DABook;
        SqlConnection CN;
        DataView DV;
        private void frmSearchBook_Load(object sender, EventArgs e)
        {
            CN = new SqlConnection();
            CN.ConnectionString = "Data Source=.; Initial Catalog=BookSample; User ID=sa; Password=123";

            string SQL = "Select * from tblBook";
            DABook = new SqlDataAdapter(SQL, CN);
            DABook.Fill(DS, "Book");
            DV = new DataView(DS.Tables["Book"]);
            dgvBook.AutoGenerateColumns = false;
            dgvBook.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBook.DataSource = DV;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (rdbBookID.Checked)
                DV.RowFilter = "BookID like '%" + txtSearch.Text + "%'";
            else
                DV.RowFilter = "BookName like '%" + txtSearch.Text + "%'";
        }

        private void dgvBook_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int i = e.RowIndex;
            if (DV[i]["Status"].ToString() == "เช่า")
            {
                MessageBox.Show("หนังสือเล่มนี้ถูกเช่าแล้ว","คำเตือน");
                return;
            }                    
            if (i >= 0 && i < DV.Count)
            {
                frmRent.BookID = DV[i]["BookID"].ToString();
                this.Close();
            }
        }
    }
}
