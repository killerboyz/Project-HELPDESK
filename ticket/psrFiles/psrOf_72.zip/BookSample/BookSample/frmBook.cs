﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookSample
{
    public partial class frmBook : Form
    {
        public frmBook()
        {
            InitializeComponent();
        }

        private void btnRent_Click(object sender, EventArgs e)
        {
            frmRent F = new frmRent();
            F.ShowDialog();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            frmReturn F = new frmReturn();
            F.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
