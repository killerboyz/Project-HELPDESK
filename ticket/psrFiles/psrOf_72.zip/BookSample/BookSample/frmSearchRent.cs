﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BookSample
{
    public partial class frmSearchRent : Form
    {
        public frmSearchRent()
        {
            InitializeComponent();
        }

        DataSet DS = new DataSet();
        SqlDataAdapter DARent;
        SqlConnection CN;
        DataView DV;
        private void frmSearchRent_Load(object sender, EventArgs e)
        {
            CN = new SqlConnection();
            CN.ConnectionString = "Data Source=.; Initial Catalog=BookSample; User ID=sa; Password=123";

            string SQL = "Select * from tblRent inner join tblMember on tblRent.MemberID = tblMember.MemberID";
            DARent = new SqlDataAdapter(SQL, CN);
            DARent.Fill(DS, "Rent");
            DV = new DataView(DS.Tables["Rent"]);
            dgvRent.AutoGenerateColumns = false;
            dgvRent.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRent.DataSource = DV;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (rdbRentID.Checked)
                DV.RowFilter = "RentID=" + txtSearch.Text;
            else
                DV.RowFilter = "MemberID like '%" + txtSearch.Text + "%'";
        }

        private void dgvRent_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int i = e.RowIndex;
            if (i >= 0 && i < DV.Count)
            {
                frmReturn.RentID = DV[i]["RentID"].ToString();
                this.Close();
            }
        }
    }
}
